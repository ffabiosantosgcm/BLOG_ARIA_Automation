# def handler(context, inputs):
#     greeting = "Hello, {0}!".format(inputs["target"])
#     print(greeting)

#     outputs = {
#       "greeting": greeting
#     }

import requests
from requests.auth import HTTPBasicAuth
import json

def handler(context, inputs):
    try:
        # Acesse inputs diretamente
        available_templates = ["projeto_portal_play_vim", "projeto_portal_play_tomcat", "projeto_portal_play_postgresql", "projeto_portal_play_patches", "projeto_portal_play_nano","projeto_portal_play_mariadb","projeto_portal_play_adduser","hello"]
        
        selected_template = inputs.get("selected_template")
        selected_template2 = inputs.get("selected_template2")
        selected_template3 = inputs.get("selected_template3")

        # Verifica se pelo menos um dos templates foi fornecido
        if not any([selected_template, selected_template2, selected_template3]):
            raise ValueError("Pelo menos um template deve ser fornecido")

        # Verifica se os templates fornecidos estão na lista de templates disponíveis
        for template in [selected_template, selected_template2, selected_template3]:
            if template and template not in available_templates:
                raise ValueError(f"Template {template} não está na lista de templates disponíveis: {available_templates}")

        awx_token = "KpxJ8i4nsUOmg3qM6HDtBurQWpUHLf"  # Substitua pelo seu token AWX

        for template_id in [selected_template, selected_template2, selected_template3]:
            if template_id:
                resultado = iniciar_job_awx(template_id, awx_token)
                print(f"Trabalho (job) AWX iniciado com sucesso. ID do trabalho: {resultado['job']}")
    except Exception as e:
        print(f"Erro: {str(e)}")

def awx_api_request(method, url, headers=None, data=None):
    # Acesse inputs diretamente
    base_url = "https://ansible-awx.virtualizandoaju.com.br/"
    api_url = f"{base_url}api/v2/{url}"

    response = requests.request(method, api_url, headers=headers, data=data, verify=False)

    if response.status_code // 100 != 2:  # Verifica se a resposta não é um código de sucesso
        raise Exception(f"Falha na solicitação para {api_url}. Código de status: {response.status_code}. Mensagem: {response.text}")

    return response.json()

def iniciar_job_awx(template_id, awx_token):
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {awx_token}"
    }

    # Criar payload para iniciar um trabalho (job)
    payload = {
        "extra_vars": "{}"
    }

    # Obter detalhes do template usando a API AWX
    template_details = awx_api_request("GET", f"job_templates/{template_id}/", headers=headers)
    
    # Verificar se o template existe
    if "id" not in template_details:
        raise Exception(f"Template AWX não encontrado com ID {template_id}")

    # Iniciar um trabalho (job) usando o template
    job_response = awx_api_request("POST", f"job_templates/{template_id}/launch/", headers=headers, data=json.dumps(payload))

    return job_response

